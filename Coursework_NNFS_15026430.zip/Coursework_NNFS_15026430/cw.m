
%UOB#15026430

%I manually, replaced �?� with 0. 
%After that 0 was replaced with 3. Because the mean of col 7  is 3.
%mean(inputData(: , 7)) 
%inputData (inputData == 0) = 3;

%importing data from File
data = csvread('breast-cancer-wisconsin.csv');
%setting my own value for epochs and weights
testEpochs=500;
testWeights=1;

%Extracting data from input into a matrix
trainingInput_data=data(1:500,2:10);
trainingOutput_data=data(1:500,11);


outputData=zeros(500,2);
for i=(1:500)
    if data(i,11)==4
        outputData(i,1)=1;
    else
        outputData(i,2)=1;
    end
end


%Im using feedforward neural network here 
nn = feedforwardnet([10,10],'traingd');
nn.trainParam.epochs = 1;
nn.trainParam.lr = 0.7;
%Force to take all the data 
nn.divideFcn = 'dividetrain';

%training 
[nn] = train(nn,trainingInput_data',outputData');

%setting the intial weights with my own weights 
weights = getwb(nn);
for i=1:size(weights,1)
    weights(i,1)=testWeights;
end
nn = setwb(nn,weights);
nn.trainParam.epochs=testEpochs;
[nn,tr] = train(nn,trainingInput_data',outputData');
weights1 = getwb(nn);

%testing
testing_data = data(501:699,2:10);
testing = sim(nn,testing_data')';
 
testOutputData = data(501:699,11);
counter=0

%here im checking of my neural network
for i=(1:199)
    [a b]=max(testing(i,:));
    if b==1 && testOutputData(i)==4
            counter=counter+1
    elseif b==2 && testOutputData(i)==2
            counter = counter+1
    end
end


acc = counter/199*100


